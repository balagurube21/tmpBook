package com.bnppf.kata.books.controller;

import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bnppf.kata.books.exception.BooksApiException;
import com.bnppf.kata.books.model.BookApiRequest;
import com.bnppf.kata.books.service.BookCollectionService;
import com.bnppf.kata.books.service.CalculateBooksPriceService;

@RestController
public class DevelopmentBooksController {

	private final CalculateBooksPriceService getBooksPriceService;
	private final BookCollectionService bookCollectionService;

	public DevelopmentBooksController(CalculateBooksPriceService getBooksPriceService,
			BookCollectionService bookCollectionService) {
		this.getBooksPriceService = getBooksPriceService;
		this.bookCollectionService = bookCollectionService;
	}

	@GetMapping("/books/getBooks")
	public ResponseEntity<?> getListOfBooks() {
		return ResponseEntity.ok(bookCollectionService.getAllBooks());
	}

	@PostMapping(path = "/books/calculateBookPrice", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<?> calculateBooksPrice(@RequestBody List<BookApiRequest> bookList) {
		try {
			bookCollectionService.validateBooksCollection(bookList);
		} catch (BooksApiException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok(getBooksPriceService.calculateBooksPrice(bookList));
	}
}
