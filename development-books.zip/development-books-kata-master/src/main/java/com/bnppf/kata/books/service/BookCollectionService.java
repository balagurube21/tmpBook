package com.bnppf.kata.books.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.bnppf.kata.books.exception.BooksApiException;
import com.bnppf.kata.books.model.BookApiRequest;
import com.bnppf.kata.books.model.BooksEnum;

@Service
public class BookCollectionService {

	public Object getAllBooks() {
		return BooksEnum.getAllBooks();
	}

	public void validateBooksCollection(List<BookApiRequest> bookInputList) throws BooksApiException {
		for (BookApiRequest bookApiRequest : bookInputList) {
			BooksEnum.getBookById(bookApiRequest.getBookId());
		}
	}

	public List<Integer> getBookIdList(List<BookApiRequest> bookInputList) {
		List<Integer> extractedList = new ArrayList<>();
		for (BookApiRequest bookApiRequest : bookInputList) {
			addBookId(extractedList, bookApiRequest);
		}
		return extractedList;
	}

	private List<Integer> addBookId(List<Integer> extractedList, BookApiRequest bookApiRequest) {
		if (bookApiRequest.getCount() == null) {
			extractedList.add(bookApiRequest.getBookId());
		} else {
			for (int i = 0; i < bookApiRequest.getCount(); i++) {
				extractedList.add(bookApiRequest.getBookId());
			}
		}
		return extractedList;
	}

}
