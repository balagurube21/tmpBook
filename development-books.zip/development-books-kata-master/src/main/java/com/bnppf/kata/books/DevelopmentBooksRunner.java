package com.bnppf.kata.books;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevelopmentBooksRunner {

	public static void main(String[] args) {
		SpringApplication.run(DevelopmentBooksRunner.class, args);
	}
}
