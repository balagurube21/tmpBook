package com.bnppf.kata.books.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookApiRequest implements Comparable<BookApiRequest> {
	private Integer bookId;
	private Integer count;

	@Override
	public int compareTo(BookApiRequest arg) {
		if (getCount() == null || arg.getCount() == null) {
			return 0;
		}
		return getCount().compareTo(arg.getCount());
	}
}
