package com.bnppf.kata.books.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.bnppf.kata.books.model.BookApiRequest;
import com.bnppf.kata.books.model.DiscountEnum;
import com.bnppf.kata.books.model.BookApiResponse;

@Service
public class CalculateBooksPriceService {

	private final BookCollectionService bookService;
	private int maxDiscountSet;

	public CalculateBooksPriceService(BookCollectionService bookService) {
		this.bookService = bookService;
	}

	public BookApiResponse calculateBooksPrice(List<BookApiRequest> bookApiRequest) {
		maxDiscountSet = bookApiRequest.size();
		Collections.sort(bookApiRequest, Collections.reverseOrder());
		List<Integer> inputBookIds = bookService.getBookIdList(bookApiRequest);
		List<List<Integer>> defaultCombinationSets = getDefaultBooksCombination(inputBookIds);
		List<List<Integer>> otherPossibleCombinationSets = getBestCombinationSet(new ArrayList<>(inputBookIds));

		double totalPriceNormalSets = getBooksPrice(defaultCombinationSets);
		double totalPriceSmallestSets = getBooksPrice(otherPossibleCombinationSets);

		return createPriceResponse(inputBookIds, totalPriceNormalSets, totalPriceSmallestSets);
	}

	private BookApiResponse createPriceResponse(List<Integer> bookListFromInput, double totalPriceNormalSets,
			double totalPriceSmallestSets) {
		double basePrice = bookListFromInput.size() * 50;
		double finalPrice = Math.min(totalPriceNormalSets, totalPriceSmallestSets);
		return BookApiResponse.builder().totalBooks(bookListFromInput.size()).bookPrice(basePrice)
				.discountedPrice(finalPrice).build();
	}

	private double getBooksPrice(List<List<Integer>> bookListSets) {
		double totalPrice = 0d;
		for (List<Integer> bookIds : bookListSets) {
			Double discountForSet = DiscountEnum.getDiscounts().get(bookIds.size());
			totalPrice += calculateDiscountedPrice(bookIds, discountForSet);
		}
		return totalPrice;
	}

	private double calculateDiscountedPrice(List<Integer> set, double discountForSet) {
		double calculatedPrice = 0d;
		double basePrice = set.size() * 50;
		double discountedPriceForSet = basePrice - ((basePrice * discountForSet) / 100.0);
		calculatedPrice += discountedPriceForSet;
		return calculatedPrice;
	}

	private List<List<Integer>> getDefaultBooksCombination(List<Integer> bookList) {
		List<List<Integer>> bookListSets = new ArrayList<>();
		List<Integer> initList = new ArrayList<>();
		bookListSets.add(initList);

		for (Integer bookId : bookList) {
			boolean bookAddedToExistingSet = addBookToExistingSet(bookListSets, bookId);
			if (!bookAddedToExistingSet) {
				addBookToNewSet(bookListSets, bookId);
			}
		}
		return bookListSets;
	}

	private List<List<Integer>> getBestCombinationSet(List<Integer> bookLists) {
		List<Integer> bookList = bookLists;
		List<List<Integer>> booksCombinationSet = new ArrayList<>();
		List<Integer> childBookList;
		for (int i = 0; i < maxDiscountSet; i++) {
			if (!bookList.isEmpty()) {
				childBookList = new ArrayList<>();
				findBestBooksCombination(bookList, childBookList);
				booksCombinationSet.add(childBookList);
			}
		}
		return booksCombinationSet;
	}

	private void findBestBooksCombination(List<Integer> bookIdList, List<Integer> childBookList) {
		int index = 0;
		while (bookIdList.size() > index) {
			if (!(childBookList.contains(bookIdList.get(index))) && childBookList.size() < maxDiscountSet - 1) {
				childBookList.add(bookIdList.get(index));
				bookIdList.remove(index);
				index = index - 1;
			}
			index++;
		}
	}

	private boolean addBookToExistingSet(List<List<Integer>> bookListSets, Integer bookId) {
		boolean bookAddedToExistingSet = false;
		for (List<Integer> list : bookListSets) {
			if (!list.contains(bookId)) {
				list.add(bookId);
				bookAddedToExistingSet = true;
				break;
			}
		}
		return bookAddedToExistingSet;
	}

	private void addBookToNewSet(List<List<Integer>> bookListSets, Integer bookId) {
		List<Integer> newSet = new ArrayList<>();
		newSet.add(bookId);
		bookListSets.add(newSet);
	}

}
